# {{MODULE_NAME}}

A Flutter package for {{MODULE_NAME}}.

## Features

- Feature 1
- Feature 2

## Getting started

```yaml
dependencies:
  {{MODULE_NAME}}: ^1.0.0
```

## Usage

```dart
import 'package:{{MODULE_NAME}}/{{MODULE_NAME}}.dart';
```