typedef PromoMap = Map<int, Promo>;

class Promo {
  final int promoCount;
  final String cashback;

  const Promo(this.promoCount, this.cashback);

  factory Promo.fromMap(dynamic map) => Promo(
        map['promo_count'] ?? 0,
        map['cashback'] ?? '',
      );

  @override
  String toString() {
    return 'Promo{promoCount: $promoCount, cashback: $cashback}';
  }
}
