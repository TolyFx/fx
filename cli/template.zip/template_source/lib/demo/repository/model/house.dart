class HouseData {
  final House house;
  final City city;
  final Location location;
  final Media media;
  final Switch switchInfo;
  final School? school;
  final Tips tips;
  final List<Tag> tags;

  const HouseData({
    required this.house,
    required this.city,
    required this.tags,
    required this.switchInfo,
    required this.tips,
    required this.media,
    required this.location,
    required this.school,
  });

  String get cover => media.images.first;

  factory HouseData.fromMap(dynamic map) {
    List<Tag> tags = [];
    if (map['tags'] is List) {
      tags = map['tags'].map<Tag>(Tag.fromMap).toList();
    }
    School? school;
    if (map['school'] != null) {
      school = School.fromMap(map['school']);
    }
    return HouseData(
      tips: Tips.fromMap(map['tips']),
      house: House.fromMap(map['house']),
      switchInfo: Switch.fromMap(map['switch']),
      tags: tags,
      school: school,
      city: City.fromMap(map['city']),
      media: Media.fromMap(map['media']),
      location: Location.fromMap(map['location']),
    );
  }
}

class School {
  final int schoolId;
  final String schoolName;
  final num distance;
  final List<Traffic> traffics;

  School({
    required this.schoolId,
    required this.schoolName,
    required this.distance,
    required this.traffics,
  });

  factory School.fromMap(dynamic map) {
    return School(
      schoolId: map['school_id'],
      schoolName: map['school_name'],
      distance: map['distance'],
      traffics: map['traffic'].map<Traffic>(Traffic.fromMap).toList(),
    );
  }
}

class Switch {
  final int isFavorite;
  final int onSiteVerification;

  const Switch({
    required this.isFavorite,
    required this.onSiteVerification,
  });

  factory Switch.fromMap(dynamic map) {
    return Switch(
      isFavorite: map['is_favorite'] ?? 0,
      onSiteVerification: map['on_site_verification'] ?? 0,
    );
  }
}

class Media {
  final List<String> images;

  Media({
    required this.images,
  });

  factory Media.fromMap(dynamic map) {
    List<String> images = [];
    if (map['images'] is List) {
      images = map['images']
          .map<String>((e) => e['media_img']['legacy_url'].toString())
          .toList();
    }

    return Media(
      images: images,
    );
  }
}

class House {
  final int houseId;
  final String sku;
  final int typeId;
  final int subTypeId;
  final int custId;
  final int supplierId;
  final int cityId;
  final int countryId;
  final int houseStatus;
  final int publishType;
  final int hasSublease;
  final String title;
  final int bookingStatus;
  final int subType;
  final int favoriteCount;
  final String leaseUnit;
  final Price rentAmount;
  final Price promoPrice;
  final Price originalPrice;
  final String minStartDate;
  final String houseUrl;
  final int ranking;

  const House({
    required this.houseId,
    required this.sku,
    required this.typeId,
    required this.subTypeId,
    required this.custId,
    required this.supplierId,
    required this.cityId,
    required this.countryId,
    required this.houseStatus,
    required this.publishType,
    required this.hasSublease,
    required this.title,
    required this.bookingStatus,
    required this.subType,
    required this.favoriteCount,
    required this.leaseUnit,
    required this.rentAmount,
    required this.promoPrice,
    required this.originalPrice,
    required this.minStartDate,
    required this.houseUrl,
    required this.ranking,
  });

  factory House.fromMap(dynamic map) => House(
        houseId: map['house_id'] ?? 0,
        sku: map['sku'] ?? '',
        typeId: map['type_id'] ?? 0,
        subTypeId: map['sub_type_id'] ?? 0,
        custId: map['cust_id'] ?? 0,
        supplierId: map['supplier_id'] ?? 0,
        cityId: map['city_id'] ?? 0,
        countryId: map['country_id'] ?? 0,
        houseStatus: map['house_status'] ?? 0,
        publishType: map['publish_type'] ?? 0,
        hasSublease: map['has_sublease'] ?? 0,
        title: map['title'] ?? '',
        bookingStatus: map['booking_status'] ?? 0,
        subType: map['sub_type'] ?? 0,
        favoriteCount: map['favorite_count'] ?? 0,
        leaseUnit: map['lease_unit'] ?? '',
        rentAmount: Price.fromMap(map['rent_amount']),
        promoPrice: Price.fromMap(map['promo_price']),
        originalPrice: Price.fromMap(map['original_price']),
        minStartDate: map['min_start_date'] ?? '',
        houseUrl: map['house_url'] ?? '',
        ranking: map['ranking'] ?? 0,
      );
}

class Price {
  final num amount;
  final String abbr;

  const Price(this.amount, this.abbr);

  factory Price.fromMap(dynamic map) => Price(
        map['amount'] ?? 0,
        map['abbr'] ?? '',
      );
}

class Tips {
  final String subTypeTitle;

  const Tips(this.subTypeTitle);

  factory Tips.fromMap(dynamic map) => Tips(
        map['sub_type']['title'] ?? '',
      );
}

class Tag {
  final int tagId;
  final String name;
  final String color;
  final String bgColor;
  final int activityTime;
  final int expireTime;
  final int sort;

  String get code => '';

  Tag({
    required this.tagId,
    required this.name,
    required this.color,
    required this.bgColor,
    required this.activityTime,
    required this.expireTime,
    required this.sort,
  });

  factory Tag.fromMap(dynamic map) => Tag(
        tagId: map['tag_id'] ?? 0,
        name: map['name'] ?? '',
        color: map['color'] ?? '',
        bgColor: map['bg_color'] ?? '',
        activityTime: map['activity_time'] ?? 0,
        expireTime: map['expire_time'] ?? 0,
        sort: map['sort'] ?? 0,
      );
}

class Traffic {
  final String type;
  final num distance;
  final int duration;

  Traffic({
    required this.type,
    required this.distance,
    required this.duration,
  });

  factory Traffic.fromMap(dynamic map) => Traffic(
        type: map['type'] ?? 0,
        distance: map['distance'] ?? '',
        duration: map['duration'] ?? '',
      );
}

class City {
  final String cityName;
  final int cityId;
  final String cityUniqueName;

  City({
    required this.cityName,
    required this.cityId,
    required this.cityUniqueName,
  });

  factory City.fromMap(dynamic map) => City(
        cityName: map['city_name'] ?? '',
        cityId: map['city_id'] ?? 0,
        cityUniqueName: map['city_unique_name'] ?? '',
      );
}

class Location {
  final String address;
  final String zipcode;
  final double lat;
  final double lng;
  final String placeId;
  final int streetViewLat;
  final int streetViewLng;

  Location({
    required this.address,
    required this.zipcode,
    required this.lat,
    required this.lng,
    required this.placeId,
    required this.streetViewLat,
    required this.streetViewLng,
  });

  factory Location.fromMap(dynamic map) => Location(
        address: map['address'] ?? '',
        zipcode: map['zipcode'] ?? '',
        lat: map['lat'] ?? 0,
        lng: map['lng'] ?? 0,
        placeId: map['place_id'] ?? '',
        streetViewLat: map['street_view_lat'] ?? 0,
        streetViewLng: map['street_view_lng'] ?? 0,
      );
}
