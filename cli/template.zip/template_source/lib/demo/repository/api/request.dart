import 'package:app_env/app_env.dart';
import 'package:request/request.dart';

import '../model/house.dart';
import '../model/payload.dart';
import '../model/promo.dart';
import 'url.dart';

class HouseRequest {

  Host get uhomes => Request()<UhomesHost>();

  Future<ApiRet<List<HouseData>>> query(HouseListPayload payload) async {
    return uhomes.post<List<HouseData>>(
      HouseListApi.listing.path,
      traceType: TraceType.tips,
      data: FormData.fromMap(payload.apiJson),
      convertor: (data) {
        return data['data'].map<HouseData>(HouseData.fromMap).toList();
      },
      decryptConvertor: EncryptUtil.aesDecrypt,
    );
  }

  Future<ApiRet<PromoMap>> queryPromo(HousePromoPayload payload) async {
    return uhomes.post<PromoMap>(
      HouseListApi.housePromo.path,
      data: FormData.fromMap(payload.apiJson),
      convertor: _convertorPromo,
    );
  }

  PromoMap _convertorPromo(dynamic data) {
    PromoMap promos = {};
    if (data is List && data.isEmpty) return promos;
    data.forEach((key, value) {
      promos[int.parse(key)] = Promo.fromMap(value);
    });
    return promos;
  }
}
