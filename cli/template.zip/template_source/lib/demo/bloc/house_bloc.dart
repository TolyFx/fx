import 'package:flutter_bloc/flutter_bloc.dart';
import 'state.dart';
import 'package:refresh/refresh.dart';
import 'package:request/request.dart';

import '../repository/repository.dart';

class HouseBloc extends Cubit<HouseState> {
  HouseRequest api = HouseRequest();

  final RefreshController refreshController = RefreshController(
    initialRefresh: false,
  );

  HouseListPayload? lastQueryPayload;
  Paginate? housePaginate;

  @override
  Future<void> close() {
    refreshController.dispose();
    return super.close();
  }

  HouseBloc() : super(const HouseState());

  void fetchPromo(List<int> houseIds, int cityId) async {
    List<int> cityIds = List.filled(houseIds.length, cityId);
    ApiRet<PromoMap> ret = await api.queryPromo(HousePromoPayload(
      houseIds: houseIds,
      cityIds: cityIds,
    ));
    if (ret.success) {
      List<int> houseIds = ret.data.keys.toList();
      List<HouseModel> models =
          state.houses.where((e) => houseIds.contains(e.houseId)).toList();
      for (HouseModel model in models) {
        String? cashback = ret.data[model.houseId]?.cashback;
        model.updatePromo(cashback);
      }
      emit(state.copyWith(total: housePaginate?.total));
    }
  }

  void loadMore() async {
    if (!(housePaginate?.pageMore ?? true)) {
      refreshController.loadNoData();
      return;
    }
    int page = state.houses.length ~/ 20 + 1;
    List<HouseModel> models = await loadHouse(page: page);
    emit(
      HouseState(
        houses: [...state.houses, ...models],
        total: housePaginate?.total,
      ),
    );
    refreshController.loadComplete();
  }

  void refresh() async {
    resetRefresh();
    await loadFirstFrame();
    refreshController.refreshCompleted();
  }

  void resetRefresh() {
    if (refreshController.footerMode?.value == LoadStatus.noMore) {
      refreshController.resetNoData();
    }
  }

  Future<void> loadFirstFrame({
    int? cityId,
    Map<String, String>? filter,
  }) async {
    resetRefresh();
    List<HouseModel> models = await loadHouse(
      page: 1,
      cityId: cityId,
      filter: filter,
    );
    emit(HouseState(houses: models, total: housePaginate?.total));
  }

  Future<List<HouseModel>> loadHouse({
    required int page,
    int pageSize = 20,
    int? cityId,
    Map<String, String>? filter,
  }) async {
    HouseListPayload payload = HouseListPayload(
      page: page,
      pageSize: 20,
      cityId: cityId ?? lastQueryPayload?.cityId ?? 7,
      filter: filter ?? lastQueryPayload?.filter,
    );
    ApiRet<List<HouseData>> ret = await api.query(payload);
    if (ret.success) {
      lastQueryPayload = payload;
      housePaginate = ret.paginate;
      List<HouseData> houseList = ret.data;
      List<HouseModel> models = [];
      for (HouseData data in houseList) {
        models.add(HouseModel.fromData(data));
      }
      List<int> houseIds = models.map((e) => e.houseId).toList();
      fetchPromo(houseIds, payload.cityId);
      return models;
    } else {
      print(ret.msg);
    }
    return [];
  }
}
