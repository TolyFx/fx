import 'package:app_env/app_env.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/cupertino.dart';
import 'package:format/format.dart';

import '../repository/model/house.dart';

class HouseState {
  final List<HouseModel> houses;
  final int? total;
  const HouseState({
    this.houses = const [],
    this.total,
  });

  HouseState copyWith({
    List<HouseModel>? houses,
    int? total,
  }) {
    return HouseState(
      houses: houses ?? this.houses,
      total: total ?? this.total,
    );
  }
}

class HouseModel extends Equatable {
  final int houseId;
  final int cityId;
  final String title;
  final int subType;
  final String price;
  final List<String> images;
  final String address;
  final int favoriteCount;
  final School? school;
  final List<TagDisplay> tags;

  String get cover => images.first;

  const HouseModel({
    required this.houseId,
    required this.cityId,
    required this.title,
    required this.address,
    required this.favoriteCount,
    required this.price,
    required this.images,
    required this.tags,
    required this.school,
    required this.subType,
  });

  factory HouseModel.fromData(HouseData data) {
    return HouseModel(
      cityId: data.city.cityId,
      houseId: data.house.houseId,
      images: data.media.images,
      favoriteCount: data.house.favoriteCount,
      title: data.house.title,
      subType: data.house.subType,
      address: data.location.address,
      price: formatLocalePrice(
        data.house.rentAmount.amount,
        data.house.rentAmount.abbr,
      ),
      tags: parserTag(data),
      school: data.school,
    );
  }

  void updatePromo(String? cashback) {
    if (cashback == null || cashback.isEmpty) return;
    tags.insert(
      0,
      TagDisplay(
        name: cashback,
        bgColor: const Color(0xFFF7EDE7),
        textColor: const Color(0xFF6D300D),
        icon: AppIcons.promo,
      ),
    );
  }

  static List<TagDisplay> parserTag(HouseData data) {
    return [
      TagDisplay(
        name: data.tips.subTypeTitle,
        icon: houseTypeIcon(data.house.subType),
        bgColor: const Color(0xfff7e8e5),
        textColor: const Color(0xff913331),
      ),
      if (data.switchInfo.onSiteVerification == 1)
        TagDisplay(
          name: '实地认证',
          icon: AppIcons.verification,
          bgColor: const Color(0xfffE7F2F5),
          textColor: const Color(0xff0C7094),
        ),
      ...data.tags.map((e) => TagDisplay(
            bgColor: hexToColor(e.bgColor),
            name: e.name,
            textColor: hexToColor(e.color),
          ))
    ];
  }

  HouseModel copyWith({
    int? houseId,
    int? cityId,
    String? title,
    String? address,
    int? favoriteCount,
    String? price,
    List<String>? images,
    List<TagDisplay>? tags,
    School? school,
    int? subType,
  }) {
    return HouseModel(
      houseId: houseId ?? this.houseId,
      cityId: cityId ?? this.cityId,
      subType: subType ?? this.subType,
      title: title ?? this.title,
      address: address ?? this.address,
      favoriteCount: favoriteCount ?? this.favoriteCount,
      price: price ?? this.price,
      images: images ?? this.images,
      tags: tags ?? this.tags,
      school: school ?? this.school,
    );
  }

  @override
  List<Object?> get props => [
        houseId,
        cityId,
        title,
        address,
        favoriteCount,
        price,
        images,
        tags,
        school,
      ];
}

class TagDisplay extends Equatable {
  final Color? bgColor;
  final String name;
  final IconData? icon;
  final Color? textColor;

  const TagDisplay({
    this.bgColor,
    required this.name,
    this.textColor,
    this.icon,
  });

  @override
  List<Object?> get props => [bgColor, name, textColor, icon];
}
