import 'package:app_env/app_env.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../bloc/bloc.dart';
import 'highlight_text.dart';
import '../repository/repository.dart';

class SliverHouseList extends StatelessWidget {
  const SliverHouseList({super.key});

  @override
  Widget build(BuildContext context) {
    List<HouseModel> data = context.watch<HouseBloc>().state.houses;
    return SliverList(
      delegate: SliverChildBuilderDelegate(
        (_, index) => HomeHouseTiled(data: data[index]),
        childCount: data.length,
      ),
    );
  }
}

class HomeHouseTiled extends StatelessWidget {
  final HouseModel data;

  const HomeHouseTiled({super.key, required this.data});

  @override
  Widget build(BuildContext context) {
    String favoriteCount = data.favoriteCount.toString();

    return Container(
      margin: const EdgeInsets.only(bottom: 8, top: 8),
      decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
                spreadRadius: 2,
                color: Colors.black.withOpacity(0.05),
                blurRadius: 4,
                offset: const Offset(0, 1))
          ],
          borderRadius: BorderRadius.circular(12)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: const BorderRadius.only(
              topRight: Radius.circular(12),
              topLeft: Radius.circular(12),
            ),
            child: SizedBox(
                height: 160,
                width: MediaQuery.sizeOf(context).width,
                child: Image.network(data.cover,fit: BoxFit.cover,))

                // CachedNetworkImage(
                //   fadeInDuration: Duration.zero,
                //   imageUrl: data.cover,
                //   fit: BoxFit.cover,
                // )),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 6),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                    child: Text(
                  data.title,
                  style: const TextStyle(
                      fontWeight: FontWeight.bold, fontSize: 15),
                )),
                Wrap(
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    Text(
                      data.price,
                      style: const TextStyle(
                          fontWeight: FontWeight.bold, fontSize: 15),
                    ),
                    const SizedBox(width: 2),
                    const Text(
                      '起/周',
                      style: TextStyle(fontSize: 12),
                    )
                  ],
                )
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0),
            child: Wrap(
                spacing: 3,
                runSpacing: 3,
                children: data.tags
                    .map((e) => TextTag(
                          backgroundColor: e.bgColor,
                          text: e.name,
                          textColor: e.textColor,
                          icon: e.icon,
                        ))
                    .toList()),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 6),
            child: Text(
              data.address,
              style: const TextStyle(fontSize: 12, height: 1),
            ),
          ),
          if (data.school != null) _SchoolDisplay(school: data.school!),
          if (data.favoriteCount != 0)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 2),
              child: Wrap(
                spacing: 4,
                crossAxisAlignment: WrapCrossAlignment.center,
                children: [
                  Icon(
                    AppIcons.favorite,
                    color: Color(0xffff5a5f),
                    size: 16,
                  ),
                  Text(
                    favoriteCount,
                    style: const TextStyle(fontSize: 12, height: 1),
                  ),
                ],
              ),
            ),
          const SizedBox(height: 6),
        ],
      ),
    );
  }
}

class _SchoolDisplay extends StatelessWidget {
  final School school;

  const _SchoolDisplay({super.key, required this.school});

  @override
  Widget build(BuildContext context) {
    String minutes = '分钟';
    String distance = '距离 ${school.schoolName} ${school.distance}';

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          HighlightText(
            distance,
            style: const TextStyle(fontSize: 12),
            richPart: {
              school.schoolName: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.bold,
              )
            },
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Wrap(
              spacing: 4,
              children: school.traffics
                  .map((e) => Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                                color: const Color(0xff636363), width: 0.7)),
                        child: Wrap(
                          spacing: 2,
                          crossAxisAlignment: WrapCrossAlignment.center,
                          children: [
                            Icon(
                              mapIcon(e.type),
                              size: 12,
                            ),
                            Text('${e.duration} $minutes',
                                style: const TextStyle(
                                  height: 1,
                                  fontSize: 12,
                                  color: Color(0xff333333),
                                )),
                          ],
                        ),
                      ))
                  .toList(),
            ),
          )
        ],
      ),
    );
  }
}

class TextTag extends StatelessWidget {
  final String text;
  final Color? backgroundColor;
  final Color? textColor;
  final IconData? icon;

  const TextTag({
    super.key,
    required this.text,
    this.backgroundColor = const Color(0xfff5f5f5),
    this.textColor,
    this.icon,
  });

  @override
  Widget build(BuildContext context) {
    Widget child = Text(
      text,
      style: TextStyle(fontSize: 9, color: textColor, height: 1),
    );

    if (icon != null) {
      child = Wrap(
        crossAxisAlignment: WrapCrossAlignment.center,
        spacing: 4,
        children: [
          Icon(
            icon,
            color: textColor,
            size: 9,
          ),
          child,
        ],
      );
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(4),
      ),
      child: child,
    );
  }
}
