import 'package:flutter/material.dart';

class HighlightText extends StatelessWidget {
  final String src;
  final Map<String, TextStyle> richPart;
  final TextStyle style;

  const HighlightText(
    this.src, {
    super.key,
    this.richPart = const {},
    required this.style,
  });

  @override
  Widget build(BuildContext context) {
    int start = 0;
    List<_Highlight> parts = [];
    richPart.forEach((key, value) {
      int index = src.indexOf(key, start);
      if (index != -1) {
        start = index;
        parts.add(_Highlight(index, key, value));
      }
    });

    return Text.rich(
      formSpan(parts),
      style: style,
    );
  }

  InlineSpan formSpan(List<_Highlight> parts) {
    parts.sort((a, b) => a.start.compareTo(b.start));

    List<TextSpan> spans = [];
    int start = 0;
    for (final highlight in parts) {
      if (highlight.start >= start) {
        // 添加普通文本部分
        if (highlight.start != start) {
          spans.add(TextSpan(
            text: src.substring(start, highlight.start),
            style: style,
          ));
        }
        spans.add(TextSpan(text: highlight.text, style: highlight.style));
        start = highlight.start + highlight.text.length;
      }
    }

    if (start < src.length) {
      spans.add(TextSpan(text: src.substring(start), style: style));
    }
    return TextSpan(children: spans, style: const TextStyle());
  }
}

// 内部类，用于存储高亮的信息
class _Highlight {
  final int start;
  final String text;
  final TextStyle style;

  _Highlight(this.start, this.text, this.style);
}
