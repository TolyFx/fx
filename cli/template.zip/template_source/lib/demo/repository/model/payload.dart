class HouseListPayload {
  final int page;
  final int pageSize;
  final int cityId;
  final Map<String, String>? filter;

  HouseListPayload({
    this.page = 1,
    this.pageSize = 20,
    required this.cityId,
    this.filter,
  });

  Map<String, dynamic> get apiJson {
    Map<String, dynamic> map = {
      'page': page,
      'page_size': pageSize,
      'city_id': cityId,
    };
    if (filter != null) {
      map.addAll(filter!);
    }
    return map;
  }

  @override
  String toString() {
    return 'HouseListPayload{page: $page, pageSize: $pageSize, cityId: $cityId, filter: $filter}';
  }
}

class HousePromoPayload {
  final List<int> houseIds;
  final List<int> cityIds;
  final String type;

  HousePromoPayload({
    required this.houseIds,
    required this.cityIds,
    this.type = 'list',
  });

  Map<String, dynamic> get apiJson => {
        'house_ids': houseIds.join(','),
        'city_id': cityIds.join(','),
        'type': type,
      };

  @override
  String toString() {
    return 'HousePromoPayload{houseIds: $houseIds, cityIds: $cityIds, type: $type}';
  }
}
