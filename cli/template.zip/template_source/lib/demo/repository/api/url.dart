import 'package:app_env/app_env.dart';
import 'package:request/request.dart';

const String houseVersion = '2.1';

enum HouseListApi {
  /// 房源列表数据
  listing("/house$houseVersion/api/houseSearch/listing", Method.post),

  /// 返现信息
  housePromo("$kUhomesApi/houseSearchV4/housePromo", Method.post),
  ;

  final String path;
  final Method? method;

  const HouseListApi(this.path, [this.method]);
}
