import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:refresh/refresh.dart';
import 'home_list.dart';
import '../bloc/bloc.dart';

class HouseListScope extends StatelessWidget {
  const HouseListScope({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider<HouseBloc>(
      lazy: false,
      create: (ctx) => HouseBloc()..loadFirstFrame(cityId: 5),
      child: HouseListSamplePage(),
    );
  }
}


class HouseListSamplePage extends StatefulWidget {
  const HouseListSamplePage({super.key});

  @override
  State<HouseListSamplePage> createState() => _HouseListSamplePageState();
}

class _HouseListSamplePageState extends State<HouseListSamplePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("展示案例"),),
      body: SmartRefresher(
        enablePullDown: true,
        enablePullUp: true,
        onRefresh: _onRefresh,
        onLoading: _onLoading,
        controller: context.read<HouseBloc>().refreshController,
        child: CustomScrollView(
          slivers: [
            SliverPadding(
              sliver: SliverHouseList(),
              padding: EdgeInsets.symmetric(horizontal: 20),
            ),
          ],
        ),
      ),
    );
  }

  void _onRefresh() async {
    await Future.delayed(const Duration(seconds: 2));
    context.read<HouseBloc>().refresh();
  }

  void _onLoading() {
    context.read<HouseBloc>().loadMore();
  }
}
